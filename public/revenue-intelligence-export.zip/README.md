# Revenue Intelligence Inbox — Export Archive
Generated on: 2026-08-21T23:59:00Z  
Total Unique Source Records: 44  

## Folder Structure
- `manifest.json`: Machine-readable JSON manifest linking every source record to its outputs.
- `manifest.csv`: Tabular CSV manifest for spreadsheet review.
- `manager-brief.md`: Executive briefing document for 21 August 2026.
- `sales-coaching/`: Dossiers for sales rep pitch coaching and objection handling.
- `deal-next-steps/`: Active commercial opportunities and partner proposals.
- `customer-follow-up/`: Account onboarding and migration support touchpoints.
- `internal-vendor/`: Critical bug reports, dunning loop escalations, and logistics tracking.
- `review-needed/`: Intake records lacking usable text or held for manual review.
